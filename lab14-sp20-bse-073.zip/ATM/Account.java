package ATM;

/**
 *
 * @author tahir
 */
import java.io.Serializable;

public class Account implements Serializable{

    private double accountNumber;
    private String name;
    private double balance;

    Account(String name, double accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.name = name;
    }
    
    public void WithDraw(int cash){
        this.balance=this.balance-cash;
//        System.out.println("Succesfully withdrawed");
    }

    public void DepositCash(double cash) {
        this.setBalance(this.getBalance() + cash);
    }

    /**
     * @return the accountNumber
     */
    public double getAccountNumber() {
        return accountNumber;
    }

    /**
     * @param accountNumber the accountNumber to set
     */
    public void setAccountNumber(double accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the balance
     */
    public double getBalance() {
        return balance;
    }

    /**
     * @param balance the balance to set
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }
}
