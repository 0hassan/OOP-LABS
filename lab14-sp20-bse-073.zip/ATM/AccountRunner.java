/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ATM;

import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author tahir
 */
public class AccountRunner {

    static Account[] user = new Account[10];

    public static void main(String[] args) throws IOException {
    //    Object_IO IO = new Object_IO();
        int i = -1;
        user[++i] = new Account("hassan1", 1111, 5000);
        user[++i] = new Account("hassan2", 2222, 5000);
        user[++i] = new Account("hassan3", 3333, 5000);
        user[++i] = new Account("hassan4", 4444, 5000);
        user[++i] = new Account("hassan5", 5555, 5000);
        user[++i] = new Account("hassan6", 6666, 5000);
        user[++i] = new Account("hassan7", 7777, 5000);
        user[++i] = new Account("hassan8", 8888, 5000);
        user[++i] = new Account("hassan9", 9999, 5000);
        user[++i] = new Account("hassan10", 1110, 5000);
        Object_IO.AddObject(user);
        Scanner scan = new Scanner(System.in);
        System.out.println("What you want to do? \n 1: Cash Deposit\n2: "
                + "Cash WithDraw\n"
                + "3: Cash Transfer\n4: Cash inquiry\n0: for Exit");
        int choise = scan.nextInt();
        while (choise != 0) {
            switch (choise) {
                case 1:
                    Deposit();
                    Object_IO.AddObject(user);
                    break;
                case 2:
                    WithDraw();
                    Object_IO.AddObject(user);
                    break;
                case 3:
                    Transfer();
                    Object_IO.AddObject(user);
                    break;
                case 4:
                    Inquiry();
                    Object_IO.AddObject(user);
                    break;
                default:
                    System.out.println("Closing...");
                    System.out.println("Thanks For Banking");
                    break;
            }
            System.out.println("What you want to do? \n 1: Cash Deposit\n2: "
                    + "Cash WithDraw\n"
                    + "3: Cash Transfer\n4: Cash inquiry\n0: for Exit");
            choise = scan.nextInt();
        }

    }

    static void Deposit() {
        Scanner scan = new Scanner(System.in);
        Account obj = AccountObj();
        System.out.print("Enter Ammount::  ");
        obj.DepositCash(scan.nextDouble());
    }

    static void WithDraw() {
        Scanner scan = new Scanner(System.in);
        Account obj = AccountObj();
        System.out.print("Enter Ammount::  ");
        obj.WithDraw(scan.nextInt());
        System.out.println("Succesfully withdrawed");
    }

    static void Transfer() {
        Scanner scan = new Scanner(System.in);
        Account obj = AccountObj();
        System.out.print("Enter Ammount::  ");
        int amount = scan.nextInt();
        obj.WithDraw(amount);
        int i = 0;
        System.out.println("Enter Receiver Acc No");
        double accNo = scan.nextDouble();
        while (accNo != user[i].getAccountNumber()) {
            i++;
        }
        obj.DepositCash(amount);
    }
// i dont know what is wrong with me. but all concept of reading is in this function sir;
    static void Inquiry() throws IOException {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter your Acc No::  ");
        Account obj = Object_IO.ReadObject(scan.nextDouble());
        System.out.println("User Name:: " + obj.getName() + "\n"
                + "Balance::    " + obj.getBalance());
    }

    static Account AccountObj() {
        int i = 0;
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter your Acc No::  ");
        double accNo = scan.nextDouble();
        while (accNo != user[i].getAccountNumber()) {
            i++;
        }
        return user[i];
    }
}
