package ATM;

/**
 *
 * @author tahir
 */
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Object_IO {

    private static ObjectInputStream read;
    private static ObjectOutputStream add;

    public static void AddObject(Account[] obj) throws IOException {
        try {
            add = new ObjectOutputStream(new FileOutputStream("Accounts.hex"));
            for (int i = 0; i < 10; i++) {
                add.writeObject(obj[i]);
            }
            add.flush();
            add.close();
        } catch (IOException ex) {
            Logger.getLogger(Object_IO.class.getName()).log(Level.SEVERE, null, ex);

        }
    }

    public static Account ReadObject(double accNo) throws IOException {
        Account obj = null;
        read = new ObjectInputStream(new FileInputStream("Accounts.hex"));
        try {
            obj=(Account) read.readObject();
            while(accNo!=obj.getAccountNumber()){
                obj=(Account) read.readObject();
            }
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Object_IO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj;
    }
}
